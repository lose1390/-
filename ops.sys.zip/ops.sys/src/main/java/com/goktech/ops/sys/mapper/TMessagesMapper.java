// 位置: src/main/java/com/goktech/ops/sys/mapper/TMessagesMapper.java
package com.goktech.ops.sys.mapper;

import com.goktech.ops.sys.entity.base.TMessage;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface TMessagesMapper {
    // 查询所有留言（带回复关系）
    List<TMessage> selectMessagesWithReplies();

    // 新增留言
    int insertMessage(TMessage message);

    // 根据ID删除留言
    int deleteMessageById(@Param("id") Long id);
}