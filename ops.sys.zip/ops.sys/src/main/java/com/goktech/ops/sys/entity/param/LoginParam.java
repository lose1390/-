package com.goktech.ops.sys.entity.param;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginParam {
    private String username;
    private String password;
}
