`t_user`/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : base

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2021-08-15 10:39:07
*/`base``base``t_user`


SET FOREIGN_KEY_CHECKS=0;

CREATE DATABASE base;

USE base;




-- ----------------------------
-- Table structure for server_bug
-- ----------------------------
DROP TABLE IF EXISTS `server_bug`;
CREATE TABLE `server_bug` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `ip` VARCHAR(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'IP地址',
  `port` VARCHAR(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '端口号',
  `content` VARCHAR(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '描述',
  `type_radio` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '类型',
  `createtime` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建时间',
  `state_radio` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '状态',
  `user` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '处理人',
  `solve_cont` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '处理内容',
  `user_id` int(11) DEFAULT NULL COMMENT '处理人id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='漏洞表';

-- ----------------------------
-- Records of server_bug
-- ----------------------------
INSERT INTO `server_bug` VALUES ('1', '1.1.1.1', '1', '测试', 'SQL注入', '2021-08-14 16:09:24', '已处理', '管理员', '已处理', '1');
INSERT INTO `server_bug` VALUES ('2', '1.1.1.1', '2', '测试', 'SQL注入', '2021-08-14 16:14:18', '已处理', '汤姆', '已解决', '28');

-- ----------------------------
-- Table structure for server_resource
-- ----------------------------
DROP TABLE IF EXISTS `server_resource`;
CREATE TABLE `server_resource` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服务器名称',
  `ip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服务器Ip',
  `state_radio` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '状态',
  `mark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `createtime` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建时间',
  `user` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '归属人',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='服务器资源表';

-- ----------------------------
-- Records of server_resource
-- ----------------------------
INSERT INTO `server_resource` VALUES ('1', '服务器1', '1.1.1.1', '启用', '测试', '2021-08-14 15:46:53', 'admin');

-- ----------------------------
-- Table structure for test
-- ----------------------------
DROP TABLE IF EXISTS `test`;
CREATE TABLE `test` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '姓名',
  `date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '日期',
  `time` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '时间',
  `sex_radio` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '男,女',
  `user_rel` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户',
  `file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '文件',
  `img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '图片',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='测试';

-- ----------------------------
-- Records of test
-- ----------------------------
INSERT INTO `test` VALUES ('17', 'Tom', '2021-06-28', '2021-06-28 10:45:09', '男', 'admin', 'http://localhost:9999/files/1624848380962', 'http://localhost:9999/files/1624848383763');

-- ----------------------------
-- Table structure for t_log
-- ----------------------------
DROP TABLE IF EXISTS `t_log`;
CREATE TABLE `t_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '序号',
  `content` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作内容',
  `time` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作时间',
  `user` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作人',
  `ip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ip',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=383 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='日志表';

-- ----------------------------
-- Records of t_log
-- ----------------------------
INSERT INTO `t_log` VALUES ('200', '用户 admin 登录系统', '2021-06-17 11:19:27', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('202', '更新角色：普通用户', '2021-06-17 14:11:48', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('203', '更新角色：普通用户', '2021-06-17 14:11:51', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('204', '更新角色：普通用户', '2021-06-17 14:11:55', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('205', '新增权限菜单：1', '2021-06-17 14:12:40', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('206', '删除权限菜单：1', '2021-06-17 14:12:51', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('207', '新增角色：财务', '2021-06-17 14:13:03', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('208', '更新角色：财务', '2021-06-17 14:13:05', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('209', '更新角色：财', '2021-06-17 14:13:09', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('210', '删除角色：财', '2021-06-17 14:13:12', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('211', '新增用户：null ', '2021-06-17 14:22:19', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('212', '新增用户：null ', '2021-06-17 14:24:26', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('213', '更新用户：admin ', '2021-06-17 14:25:49', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('214', '更新用户：admin ', '2021-06-17 14:26:08', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('215', '用户 zcb01 注册账号成功', '2021-06-17 14:28:46', 'zcb01', '127.0.0.1');
INSERT INTO `t_log` VALUES ('216', '用户 zcb01 登录系统', '2021-06-17 14:29:00', 'zcb01', '127.0.0.1');
INSERT INTO `t_log` VALUES ('217', '用户 zcb01 登录系统', '2021-06-17 14:29:20', 'zcb01', '127.0.0.1');
INSERT INTO `t_log` VALUES ('218', '用户 admin 登录系统', '2021-06-17 14:29:41', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('219', '更新角色：普通用户', '2021-06-17 14:29:59', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('220', '用户 zcb01 登录系统', '2021-06-17 14:30:16', 'zcb01', '127.0.0.1');
INSERT INTO `t_log` VALUES ('221', '用户 zcb01 登录系统', '2021-06-17 14:30:43', 'zcb01', '127.0.0.1');
INSERT INTO `t_log` VALUES ('222', '用户 admin 登录系统', '2021-06-17 14:31:02', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('223', '更新角色：普通用户', '2021-06-17 14:31:26', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('224', '用户 zcb01 登录系统', '2021-06-17 14:31:49', 'zcb01', '127.0.0.1');
INSERT INTO `t_log` VALUES ('225', '用户 admin 登录系统', '2021-06-17 14:31:59', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('226', '新增用户：null ', '2021-06-17 14:32:34', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('227', '新增用户：zcb02 ', '2021-06-17 14:41:52', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('228', '新增用户：zcb0102 ', '2021-06-17 14:42:15', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('229', '删除用户 zcb0102 ', '2021-06-17 14:42:37', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('230', '删除用户 zcb02 ', '2021-06-17 14:50:28', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('231', '新增用户：zcb02 ', '2021-06-17 14:51:05', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('232', '更新用户：zcb02 ', '2021-06-17 14:51:14', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('233', '更新用户：zcb02 ', '2021-06-17 14:51:20', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('234', '用户 zcb02 登录系统', '2021-06-17 14:51:29', 'zcb02', '127.0.0.1');
INSERT INTO `t_log` VALUES ('235', '用户 zcb02 登录系统', '2021-06-17 14:51:29', 'zcb02', '127.0.0.1');
INSERT INTO `t_log` VALUES ('236', '用户 admin 登录系统', '2021-06-17 14:51:42', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('237', '用户 zcb01 登录系统', '2021-06-17 14:52:38', 'zcb01', '127.0.0.1');
INSERT INTO `t_log` VALUES ('238', '用户 admin 登录系统', '2021-06-17 14:52:45', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('239', '删除用户 zcb01 ', '2021-06-17 14:52:55', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('240', '更新角色：超级管理员', '2021-06-17 15:14:14', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('241', '更新角色：普通用户', '2021-06-17 15:14:18', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('242', '用户 zcb01 登录系统', '2021-06-17 15:15:06', 'zcb01', '127.0.0.1');
INSERT INTO `t_log` VALUES ('243', '更新用户：zcb01 ', '2021-06-17 15:15:42', 'zcb01', '127.0.0.1');
INSERT INTO `t_log` VALUES ('244', '用户 admin 登录系统', '2021-06-17 15:32:12', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('245', '新增用户：zzz ', '2021-06-17 15:32:32', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('246', '删除用户 zzz ', '2021-06-17 15:32:41', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('247', '更新用户：admin ', '2021-06-17 15:32:57', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('248', '用户 zcb01 登录系统', '2021-06-17 15:33:05', 'zcb01', '127.0.0.1');
INSERT INTO `t_log` VALUES ('249', '更新用户：zcb01 ', '2021-06-17 15:33:11', 'zcb01', '127.0.0.1');
INSERT INTO `t_log` VALUES ('250', '用户 admin 登录系统', '2021-06-17 15:33:17', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('251', '用户 admin 登录系统', '2021-06-17 15:40:12', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('252', '更新角色：超级管理员', '2021-06-17 16:03:59', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('253', '更新权限菜单：测试模块管理', '2021-06-17 16:05:06', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('254', '用户 admin 登录系统', '2021-06-17 17:00:36', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('255', '用户 admin 登录系统', '2021-06-17 17:01:29', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('256', '用户 admin 登录系统', '2021-06-17 17:07:39', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('257', '用户 admin 登录系统', '2021-06-18 15:05:04', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('258', '更新权限菜单：测试模块管理', '2021-06-18 15:05:30', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('259', '更新角色：超级管理员', '2021-06-18 15:05:37', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('260', '用户 admin 登录系统', '2021-06-18 16:48:13', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('261', '更新角色：超级管理员', '2021-06-18 16:48:25', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('262', '用户 admin 登录系统', '2021-06-21 10:22:09', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('263', '更新角色：超级管理员', '2021-06-21 10:22:31', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('264', '更新用户：admin ', '2021-06-21 14:12:37', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('265', '用户 zcb01 登录系统', '2021-06-21 14:12:56', 'zcb01', '127.0.0.1');
INSERT INTO `t_log` VALUES ('266', '更新用户：zcb01 ', '2021-06-21 14:13:03', 'zcb01', '127.0.0.1');
INSERT INTO `t_log` VALUES ('267', '用户 admin 登录系统', '2021-06-21 14:13:12', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('268', '更新权限菜单：测试模块管', '2021-06-21 14:32:52', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('269', '更新权限菜单：测试模块管理', '2021-06-21 14:33:04', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('270', '新增权限菜单：1', '2021-06-21 14:33:10', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('271', '删除权限菜单：1', '2021-06-21 14:33:14', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('272', '新增角色：1', '2021-06-21 15:11:37', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('273', '更新角色：12', '2021-06-21 15:11:43', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('274', '更新角色：12', '2021-06-21 15:11:47', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('275', '删除角色：12', '2021-06-21 15:12:00', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('276', '新增用户：zzx1 ', '2021-06-21 15:54:58', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('277', '更新用户：zzx1 ', '2021-06-21 16:03:15', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('278', '更新用户：zzx1 ', '2021-06-21 16:03:24', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('279', '更新用户：zzx1 ', '2021-06-21 16:03:26', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('280', '更新用户：zzx1 ', '2021-06-21 16:03:29', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('281', '删除用户 zzx1 ', '2021-06-21 16:03:33', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('282', '用户 admin 登录系统', '2021-06-21 16:06:23', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('283', '用户 zcb01 登录系统', '2021-06-21 16:06:31', 'zcb01', '127.0.0.1');
INSERT INTO `t_log` VALUES ('284', '用户 zcb01 登录系统', '2021-06-21 16:07:12', 'zcb01', '127.0.0.1');
INSERT INTO `t_log` VALUES ('285', '用户 zzz111 注册账号成功', '2021-06-21 16:07:34', 'zzz111', '127.0.0.1');
INSERT INTO `t_log` VALUES ('286', '用户 zzz111 登录系统', '2021-06-21 16:07:39', 'zzz111', '127.0.0.1');
INSERT INTO `t_log` VALUES ('287', '用户 admin 登录系统', '2021-06-21 16:11:07', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('288', '更新权限菜单：首页', '2021-06-21 16:15:38', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('289', '更新用户：admin ', '2021-06-21 16:19:12', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('290', '更新角色：普通用户', '2021-06-21 16:20:40', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('291', '用户 admin 登录系统', '2021-06-21 16:29:54', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('292', '更新用户：admin ', '2021-06-21 16:30:08', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('293', '用户 admin 登录系统', '2021-06-21 16:30:22', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('294', '用户 admin 登录系统', '2021-06-21 16:38:38', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('295', '用户 admin 登录系统', '2021-06-23 09:30:16', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('296', '用户 admin 登录系统', '2021-06-23 09:32:02', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('297', '用户 admin 登录系统', '2021-06-23 15:31:03', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('298', '用户 admin 登录系统', '2021-06-23 15:32:32', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('299', '用户 admin 登录系统', '2021-06-23 15:40:53', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('300', '用户 admin 登录系统', '2021-06-23 15:41:25', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('301', '用户 admin 登录系统', '2021-06-24 09:26:25', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('302', '用户 admin 登录系统', '2021-06-25 10:56:46', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('303', '用户 admin 登录系统', '2021-06-25 11:28:51', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('304', '更新角色：超级管理员', '2021-06-25 11:28:57', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('305', '用户 admin 登录系统', '2021-06-25 11:38:00', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('306', '用户 admin 登录系统', '2021-06-28 10:09:50', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('307', '更新权限菜单：测试模块管理', '2021-06-28 10:10:01', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('308', '更新角色：超级管理员', '2021-06-28 10:10:08', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('309', '用户 admin 登录系统', '2021-06-28 10:43:46', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('310', '更新权限菜单：测试模块管理', '2021-06-28 10:44:07', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('311', '用户 admin 登录系统', '2021-06-30 09:12:37', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('312', '用户 admin 登录系统', '2021-06-30 10:36:58', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('313', '更新角色：超级管理员', '2021-06-30 10:44:06', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('314', '用户 admin 登录系统', '2021-06-30 10:46:24', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('315', '新增用户：zzz1 ', '2021-06-30 10:46:49', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('316', '更新用户：zzz1 ', '2021-06-30 10:46:54', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('317', '更新用户：zzz1 ', '2021-06-30 10:47:05', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('318', '更新用户：zzz1 ', '2021-06-30 10:47:08', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('319', '更新用户：zzz1 ', '2021-06-30 10:47:10', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('320', '删除用户 zzz1 ', '2021-06-30 10:47:13', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('321', '更新角色：超级管理员', '2021-06-30 10:47:21', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('322', '用户 admin 登录系统', '2021-06-30 10:51:36', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('323', '更新角色：超级管理员', '2021-06-30 10:51:40', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('324', '用户 admin 登录系统', '2021-06-30 10:56:22', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('325', '更新角色：超级管理员', '2021-06-30 10:56:26', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('326', '更新角色：超级管理员', '2021-06-30 10:56:37', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('327', '新增角色：1', '2021-06-30 10:56:47', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('328', '删除角色：1', '2021-06-30 10:56:49', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('329', '新增权限菜单：1', '2021-06-30 10:56:58', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('330', '更新权限菜单：1', '2021-06-30 10:57:05', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('331', '删除权限菜单：1', '2021-06-30 10:57:09', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('332', '更新权限菜单：测试模块管理', '2021-06-30 10:57:15', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('333', '更新用户：admin ', '2021-06-30 11:30:14', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('334', '用户 admin 登录系统', '2021-07-06 10:55:55', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('335', '用户 admin 登录系统', '2021-07-06 10:55:55', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('336', '用户 admin 登录系统', '2021-07-07 16:07:56', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('337', '用户 admin 登录系统', '2021-07-14 11:27:56', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('338', '用户 admin 登录系统', '2021-07-18 21:55:04', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('339', '用户 admin 登录系统', '2021-07-18 21:56:31', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('340', '用户 admin 登录系统', '2021-07-18 21:58:52', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('341', '更新角色：超级管理员', '2021-07-18 21:59:09', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('342', '用户 admin 登录系统', '2021-07-18 22:02:19', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('343', '用户 admin 登录系统', '2021-07-27 16:57:01', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('344', '用户 admin 登录系统', '2021-07-27 16:58:44', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('345', '用户 admin 登录系统', '2021-07-27 17:11:52', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('346', '用户 admin 登录系统', '2021-07-27 17:43:44', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('347', '用户 admin 登录系统', '2021-07-27 17:46:11', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('348', '用户 zcb001 注册账号成功', '2021-07-27 17:52:33', 'zcb001', '127.0.0.1');
INSERT INTO `t_log` VALUES ('349', '用户 zcb001 登录系统', '2021-07-27 17:56:32', 'zcb001', '127.0.0.1');
INSERT INTO `t_log` VALUES ('350', '用户 admin 登录系统', '2021-07-27 17:56:42', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('351', '新增用户：zcb002 ', '2021-07-27 18:08:57', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('352', '用户 admin 登录系统', '2021-07-27 18:31:46', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('353', '更新用户：zcb01 ', '2021-07-27 18:38:07', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('354', '用户 admin 登录系统', '2021-07-27 19:20:34', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('355', '用户 admin 登录系统', '2021-07-27 19:27:43', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('356', '新增用户：zcb0001 ', '2021-07-28 14:47:24', 'admin', '127.0.0.1');
INSERT INTO `t_log` VALUES ('357', '用户 admin 登录系统', '2021-08-14 09:59:46', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('358', '用户 admin 登录系统', '2021-08-14 10:00:06', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('359', '用户 admin 登录系统', '2021-08-14 10:01:10', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('360', '用户 admin 登录系统', '2021-08-14 10:11:28', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('361', '用户 admin 登录系统', '2021-08-14 10:26:15', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('362', '更新角色：超级管理员', '2021-08-14 10:26:21', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('363', '更新权限菜单：测试模块管理', '2021-08-14 10:26:37', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('364', '更新角色：超级管理员', '2021-08-14 11:20:34', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('365', '更新权限菜单：测试模块管理', '2021-08-14 11:26:00', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('366', '用户 admin 登录系统', '2021-08-14 11:33:19', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('367', '用户 admin 登录系统', '2021-08-14 14:45:01', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('368', '用户 admin 登录系统', '2021-08-14 15:01:09', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('369', '新增用户：admin ', '2021-08-14 15:06:58', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('370', '新增用户：admin ', '2021-08-14 15:09:49', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('371', '更新用户：zcb123 ', '2021-08-14 15:09:57', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('372', '删除用户 zcb123 ', '2021-08-14 15:10:00', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('373', '更新权限菜单：服务器资源管理', '2021-08-14 15:25:21', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('374', '更新角色：超级管理员', '2021-08-14 15:25:27', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('375', '更新角色：超级管理员', '2021-08-14 15:32:27', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('376', '更新权限菜单：漏洞资源管理', '2021-08-14 15:33:22', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('377', '更新角色：超级管理员', '2021-08-14 15:36:43', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('378', '用户 admin 登录系统', '2021-08-14 16:36:45', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('379', '用户 admin 登录系统', '2021-08-14 16:46:55', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('380', '用户 admin 登录系统', '2021-08-14 22:34:38', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('381', '用户 admin 登录系统', '2021-08-15 09:48:44', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES ('382', '更新角色：超级管理员', '2021-08-15 09:48:55', 'admin', '0:0:0:0:0:0:0:1');

-- ----------------------------
-- Table structure for t_message
-- ----------------------------
DROP TABLE IF EXISTS `t_message`;
CREATE TABLE `t_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `content` text CHARACTER SET utf8mb4 COMMENT '内容',
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '评论人',
  `time` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '评论时间',
  `parent_id` bigint(20) DEFAULT NULL COMMENT '父ID',
  `foreign_id` bigint(20) DEFAULT '0' COMMENT '关联id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='留言表';

-- ----------------------------
-- Records of t_message
-- ----------------------------
INSERT INTO `t_message` VALUES ('25', '666', 'admin', '2021-06-17 15:14:45', null, '0');
INSERT INTO `t_message` VALUES ('26', '66666', 'admin', '2021-06-17 15:14:53', '25', '0');
INSERT INTO `t_message` VALUES ('27', '1', 'zcb01', '2021-06-17 15:15:12', '26', '0');

-- ----------------------------
-- Table structure for t_notice
-- ----------------------------
DROP TABLE IF EXISTS `t_notice`;
CREATE TABLE `t_notice` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标题',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '内容',
  `time` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='公告表';

-- ----------------------------
-- Records of t_notice
-- ----------------------------
INSERT INTO `t_notice` VALUES ('4', '好消息', '跳楼大甩卖', '2021-06-17 14:57:15');

-- ----------------------------
-- Table structure for t_permission
-- ----------------------------
DROP TABLE IF EXISTS `t_permission`;
CREATE TABLE `t_permission` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `path` varchar(255) DEFAULT NULL COMMENT '菜单路径',
  `icon` varchar(255) DEFAULT NULL COMMENT '图标',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='权限菜单表';

-- ----------------------------
-- Records of t_permission
-- ----------------------------
INSERT INTO `t_permission` VALUES ('1', '首页', '首页', '/home', 's-home');
INSERT INTO `t_permission` VALUES ('2', '用户管理', '用户管理', '/user', 'user-solid');
INSERT INTO `t_permission` VALUES ('3', '角色管理', '角色管理', '/role', 's-cooperation');
INSERT INTO `t_permission` VALUES ('4', '菜单管理', '菜单管理', '/permission', 'menu');
INSERT INTO `t_permission` VALUES ('5', '公告管理', '公告管理', '/notice', 'data-board');
INSERT INTO `t_permission` VALUES ('6', '日志管理', '日志管理', '/log', 'notebook-2');
INSERT INTO `t_permission` VALUES ('7', '留言板', '留言板', '/message', 'message');
INSERT INTO `t_permission` VALUES ('9', '测试模块管理', '测试模块管理', '/test', 's-data');
INSERT INTO `t_permission` VALUES ('10', '服务器资源管理', '服务器资源管理', '/serverResource', 's-data');
INSERT INTO `t_permission` VALUES ('11', '漏洞资源管理', '漏洞资源管理', '/serverBug', 's-data');
INSERT INTO `t_permission` VALUES ('12', '漏洞监管管理', '漏洞监管管理', '/serverBugManage', 's-data');

-- ----------------------------
-- Table structure for t_role
-- ----------------------------
DROP TABLE IF EXISTS `t_role`;
CREATE TABLE `t_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `permission` varchar(2000) DEFAULT NULL COMMENT '权限列表',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='角色表';

-- ----------------------------
-- Records of t_role
-- ----------------------------
INSERT INTO `t_role` VALUES ('1', '超级管理员', '所有权限', '[1,2,3,4,5,6,7,8,10,11,12]');
INSERT INTO `t_role` VALUES ('2', '普通用户', '部分权限', '[1,7]');

-- ----------------------------
-- Table structure for t_user
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户名',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '密码',
  `nick_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '昵称',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邮箱',
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '手机号',
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '头像',
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '角色',
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '地址',
  `age` int(11) DEFAULT NULL COMMENT '年龄',
  `sex` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '性别',
  `createTime` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='用户表';

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES ('1', 'admin', 'admin', '管理员', '123', '13978786565', '1624255957677', '[1]', '北京', '20', '男', '2021-08-14 15:04:57');
INSERT INTO `t_user` VALUES ('28', 'zcb01', '123456', '汤姆', '1@qq.com', '15012345678', '1624255983678', '[2]', '上海', '19', '男', '2021-08-14 15:05:16');



iNSERT INTO `t_notice` (`title`, `content`, `time`) 
VALUES ('系统升级通知', '系统将于2025年06月18日23:00-24:00进行维护升级，期间暂停服务，给您带来不便敬请谅解。', '2025-06-17 15:30:00');


